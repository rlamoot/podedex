var autocomplete=function(){
    var availableTutorials  =  [
        "Piloswine",
        "Corsola",
        "Remoraid",
        "Octillery",
        "Delibird",
        "Mantine",
        "Skarmory",
        "Houndour",
        "Houndoom",
        "Kingdra",
        "Phanpy",
        "Donphan",
        "Porygon2",
        "Stantler",
        "Smeargle",
        "Tyrogue",
        "Hitmontop",
        "Smoochum",
        "Elekid",
        "Magby",
    ];
    $( "#search" ).autocomplete({
        source: availableTutorials
    });
};

var catchSubmit = function (e) {
    e.preventDefault();
    var search = $("#search").val();
    console.log(search);


    $.ajax({
        type: "GET",
        url: "https://pokeapi.co/api/v2/pokemon/" + search,
        dataType: "json"


    }).done(function (data) {
        console.log(data);
        console.log(data.forms[0].name);
        console.log(data.abilities[0].ability.name);

        var name =data.forms[0].name ;
        var ability1= data.abilities[0].ability.name;
        var ability2=data.abilities[1].ability.name;
        var ability3=data.abilities[2].ability.name;
        var moves=data.moves;


        $("#name").append("<p>name:"+ name + "</p>");
        $("#info").append("<p> Ability1: "+ ability1 +"</p>");
        $("#info").append("<p> Ability2: "+ ability2 +"</p>");
        $("#info").append("<p> Ability3: "+ ability3 +"</p>");

    });

};

$(document).ready(function() {
    autocomplete();
    $('form').on('submit',catchSubmit);
});