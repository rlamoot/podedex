$document.ready(function () {
    $("#scrollbox").scroll(function(){
        $("span").text( x+= 1);
    });
});