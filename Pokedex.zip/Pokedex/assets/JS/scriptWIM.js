var autocomplete=function(){
    var availableTutorials  =  [
        "piloswine",
        "corsola",
        "remoraid",
        "octillery",
        "delibird",
        "mantine",
        "skarmory",
        "houndour",
        "houndoom",
        "kingdra",
        "phanpy",
        "donphan",
        "porygon2",
        "stantler",
        "smeargle",
        "tyrogue",
        "hitmontop",
        "smoochum",
        "elekid",
        "magby",
    ];
    $( "#search" ).autocomplete({
        source: availableTutorials
    });
};

var catchSubmit = function (e) {
    e.preventDefault();
    var search = $("#search").val();
    console.log(search);


    $.ajax({
        type: "GET",
        url: "https://pokeapi.co/api/v2/pokemon/" + search,
        dataType: "json"


    }).done(function (data) {
        console.log(data);
        console.log(data.forms[0].name);
        console.log(data.abilities[0].ability.name);

        var name =data.forms[0].name ;
        var ability1= data.abilities[0].ability.name;
        var ability2=data.abilities[1].ability.name;
        var ability3=data.abilities[2].ability.name;
        var moves=data.moves;


        $("#name").append("<p>name:"+ name + "</p>");
        $("#info").append("<p> Ability1: "+ ability1 +"</p>");
        $("#info").append("<p> Ability2: "+ ability2 +"</p>");
        $("#info").append("<p> Ability3: "+ ability3 +"</p>");

    });

};

var ToonFoto = function (e) {
    e.preventDefault();
    var ToonPokemon = $('#search').val().toLowerCase();
    var ToonFotoPokemon = "http://img.pokemondb.net/artwork/" + ToonPokemon + ".jpg";

    $('#picture').attr("src", ToonFotoPokemon);

};

var ToonNaam = function () {
    var naam = $('#search').val();
    $('#name').html(naam);


};

$(document).ready(function() {
    autocomplete();
    $('#submit').on('click',catchSubmit);
    $('#submit').on('click', ToonFoto);
    $('#submit').on('click', ToonNaam);
    $("#scrollbox").scroll(function(){
        $("span").text( x+= 1);
    });
});

