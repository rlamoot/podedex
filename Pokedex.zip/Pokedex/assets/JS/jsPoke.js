var ToonFoto = function (e) {
    e.preventDefault();
    var ToonPokemon = $('#search').val().toLowerCase();
    var ToonFotoPokemon = "http://img.pokemondb.net/artwork/" + ToonPokemon + ".jpg";

    $('#picture').attr("src", ToonFotoPokemon);

};

var ToonNaam = function () {
    var naam = $('#search').val();
    $('#name').html(naam);


};


$(document).ready(function() {
    $('#submit').on('click', ToonFoto);
    $('#submit').on('click', ToonNaam);

});